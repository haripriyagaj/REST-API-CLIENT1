package dhivya;

import java.net.http.*;
import java.net.URI;
import java.io.IOException;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class App {

    // Method to fetch weather data
    public static String fetchWeatherData(String city, String apiKey) throws IOException, InterruptedException {
        String apiUrl = "http://api.openweathermap.org/data/2.5/weather?q=" + city + "&appid=" + apiKey;

        // Create an HttpClient
        HttpClient client = HttpClient.newHttpClient();

        // Build the HTTP request
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(apiUrl))
                .GET()
                .build();

        // Send the request and get the response
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        return response.body();
    }

    // Method to parse JSON data
    public static void parseAndDisplayWeather(String jsonData) {
        // Parse JSON using Gson
        JsonObject jsonObject = JsonParser.parseString(jsonData).getAsJsonObject();

        // Extract relevant data
        String cityName = jsonObject.get("name").getAsString();
        JsonObject main = jsonObject.getAsJsonObject("main");
        double temp = main.get("temp").getAsDouble();
        double feelsLike = main.get("feels_like").getAsDouble();
        int humidity = main.get("humidity").getAsInt();

        // Print the weather details
        System.out.println("Weather Data:");
        System.out.println("City: " + cityName);
        System.out.println("Temperature: " + temp + "K");
        System.out.println("Feels Like: " + feelsLike + "K");
        System.out.println("Humidity: " + humidity + "%");
    }

    public static void main(String[] args) {
        String city = "chennai";
        String apiKey = "e507feb5f1afb864f9c4f8e985695b80"; // Replace with your actual API key

        try {
            // Fetch weather data
            String jsonData = fetchWeatherData(city, apiKey);

            // Parse and display the weather data
            parseAndDisplayWeather(jsonData);
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}
